<?php
// Database connection details
$server = "localhost";
$username = "root";
$password = "";
$dbname = "educollab";

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$a = $_POST['code'];
$b = $_POST['name'];
$c = $_POST['lesson'];
$d = $_POST['dis'];
$e = $_POST['price'];
$image = $a . ".jpg";
$f = $_POST['c'];

// Define the destination for the uploaded file
$dest = "thumb/" . $image;

// Copy the uploaded file to the destination
if (!move_uploaded_file($_FILES['userfile']['tmp_name'], $dest)) {
    die("Possible file upload attack!\n");
}

// Check if the code already exists in the database
$stmt_check = $conn->prepare("SELECT code FROM course WHERE code = ?");
$stmt_check->bind_param("s", $a);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    $stmt_check->close();
    die("Error: Duplicate entry '$a' for key 1");
}

$stmt_check->close();

// Prepare and execute the SQL query
$stmt = $conn->prepare("INSERT INTO course (code, name, lesson, dis, price, image) VALUES (?, ?, ?, ?, ?, ?)");

// Check if the preparation of the statement was successful
if ($stmt === false) {
    die("Failed to prepare the statement: " . $conn->error);
}

$stmt->bind_param("ssssss", $a, $b, $c, $d, $e, $image);

if ($stmt->execute()) {
    echo "<script>window.location='college.php'; </script>";
} else {
    echo "Error: " . $stmt->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>

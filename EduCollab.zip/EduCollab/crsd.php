<?php
    // Database connection details
    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "educollab";

    // Create connection
    $conn = new mysqli($server, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the code from the query string
    $code = $_GET['code'];

    // Define the query
    $qry = "SELECT * FROM course WHERE code = '$code'";

    // Execute the query
    $rc = $conn->query($qry);

    // Check if the query was successful
    if ($rc === false) {
        die("Error: " . $conn->error);
    }

    // Fetch the row
    $row = $rc->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .custom-media img {
            width: 100%;
            height: 300px; /* Set a fixed height */
            object-fit: cover; /* Ensure the image covers the area without distortion */
            border-radius: 10px; /* Rounded corners */
        }
        .car__item__text {
            text-align: center;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .mycl {
            font-size: 1.8em;
            font-weight: bold;
            color: #343a40;
        }
        .db {
            font-size: 1.1em;
            color: #495057;
        }
        .section-title {
            margin-bottom: 40px;
        }
        .site-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            text-transform: uppercase;
            font-weight: bold;
            border-radius: 5px;
        }
        .site-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<section class="about spad py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title text-center">
                    <h2>Course Details</h2>
                </div>
                <div class="car__item__text mb-4">
                    <div class="col-lg-12">
                        <h3 class="mycl"><?php echo $row['name']; ?></h3>
                    </div>
                    <div class="custom-media">
                        <?php echo "<img class='img-responsive img-hover' src='thumb/" . htmlspecialchars($row['image'], ENT_QUOTES, 'UTF-8') . "' alt='Course Image'>"; ?> 
                    </div>
                </div>
                <div class="section-title about-title">
                    <div class="car__item__text">
                        <h2>Description</h2>
                        <p class="text-muted"><?php echo $row['dis']; ?></p>
                        <br>
                        <h2>Course Details</h2>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td><h5 class="db">Total Lessons</h5></td>
                                        <td><h5 class="db"><?php echo $row['lesson']; ?></h5></td>
                                    </tr>
                                    <tr>
                                        <td><h5 class="db">Course Duration</h5></td>
                                        <td><h5 class="db"><?php echo $row['dis']; ?></h5></td>
                                    </tr>
                                    <tr>
                                        <td><h5 class="db">Price</h5></td>
                                        <td><h5 class="db"><?php echo $row['price']; ?></h5></td>
                                    </tr>
                                </tbody>
                            </table>
                            <?php echo "<a href='index.html?code=" . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . "'><button type='button' class='site-btn'>purchase Course <i class='fa fa-car'></i></button></a>"; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
    // Close the connection
    $conn->close();
?>

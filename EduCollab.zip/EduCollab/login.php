<?php 
			include('nav.php');
?>


  <div class="untree_co-section">
    <div class="container">

      <div class="row mb-5 justify-content-center">
        <div class="col-lg-12 mx-auto order-1" data-aos="fade-up" data-aos-delay="200">
          <form action="#" class="form-box">
            <div class="row">
              <div class="col-12 mb-3">
                <input type="text" class="form-control" placeholder="Email">
              </div>
              <div class="col-12 mb-3">
                <input type="password" class="form-control" placeholder="Password">
              </div>

              <div class="col-12 mb-3">
                <label class="control control--checkbox">
                  <span class="caption">Remember me</span>
                  <input type="checkbox" checked="checked" />
                  <div class="control__indicator"></div>
                </label>
              </div>

              <div class="col-12">
                <input type="submit" value="Login" class="btn col-md-12 btn-primary">
              <label style="float: right;">Don't have an account?Click here</label>
              </div>
            </div>
          </form>
        </div>
      </div>

      
    </div>
  </div> <!-- /.untree_co-section -->

  <div class="site-footer">

    <div class="container">
      <div class="row">
        <div class="col-lg-2 mr-auto">
          <div class="widget">
            <div class="widget">
              <h3>MBA</h3>
              <ul class="list-unstyled float-left links">
                <li><a href="#">MBA</a></li>
                <li><a href="#">TOP MBA COLLEGES</a></li>
                <li><a href="#">COMPARE COLLEGES</a></li>
                <li><a href="#">MBA EXAMS</a></li>
                <li><a href="#">ONLINE MBA</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-2 ml-auto">
          <div class="widget">
            <h3>ENGINEERING</h3>
            <ul class="list-unstyled float-left links">
              <li><a href="#">ENGINEERING</a></li>
              <li><a href="#">TOP ENGINEERING COLLEGES</a></li>
              <li><a href="#">EXAMS</a></li>
              <li><a href="#">COMPARE COLLEGES</a></li>
              <li><a href="#">PHD</a></li>
            </ul>
          </div> <!-- /.widget -->
        </div> <!-- /.col-lg-3 -->
        <div class="col-lg-2 ml-auto">
          <div class="widget">
            <h3>MEDICAL</h3>
            <ul class="list-unstyled float-left links">
              <li><a href="#">MEDICAL</a></li>
              <li><a href="#">MEDICAL COLLEGES</a></li>
              <li><a href="#">MBBS</a></li>
              <li><a href="#">MD</a></li>
              <li><a href="#">NEET</a></li>
            </ul>
          </div> <!-- /.widget -->
        </div> <!-- /.col-lg-3 -->

        <div class="col-lg-2 ml-auto">
          <div class="widget">
            <h3>SARKARI EXAMS</h3>
            <ul class="list-unstyled float-left links">
              <li><a href="#">UPSC</a></li>
              <li><a href="#">RRB GROUP D</a></li>
              <li><a href="#">CTNET</a></li>
              <li><a href="#">SSC GD</a></li>
              <li><a href="#">POST GDS</a></li>
            </ul>
          </div>
        </div>

        <div class="col-lg-2 ml-auto">
          <div class="widget">
            <h3>ABOUT EDUCOLLAB</h3>
            <ul class="list-unstyled float-left links">
              <li><a href="#">ABOUT</a></li>
              <li><a href="#">MANAGEMENT TEAM</a></li>
              <li><a href="#">FAQS</a></li>
              <li><a href="#">CONTACTS</a></li>
              <li><a href="#">EDUCOLLAB AUTHORS</a></li>
            </ul>
          </div> <!-- /.widget -->
        </div> <!-- /.col-lg-3 -->
        <div class="col-lg-2 ml-auto">
          <div class="widget">
            <h3>MORE</h3>
            <ul class="list-unstyled float-left links">
              <li><a href="#">BANKING</a></li>
              <li><a href="#">CERTIFIED COURSE</a></li>
              <li><a href="#">TRENDING BRANCH</a></li>
              <li><a href="#">CAREER TEST</a></li>
              <li><a href="#">CHAT WITH COUNSELLOR</a></li>
            </ul>
          </div> <!-- /.widget -->
        </div> <!-- /.col-lg-3 -->

        <div class="row col-lg-12 mt-5">
          <div class="col-lg-12 text-center">
            <p>Copyright &copy;
              <script>document.write(new Date().getFullYear());</script>. All Rights Reserved. By EduCollab &mdash;
              Designed by Vaja Aashish & Rajput Aastha
          </div>
        </div>
      </div>
    </div>

    <div id="overlayer"></div>
    <div class="loader">
      <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
      // Show the active content section
      $(".nav-link").on("click", function () {
        $(".content-section").hide();
        $($(this).attr("href")).show();
      });
    </script>

    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/custom.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.5.0/dist/js/bootstrap.min.js"></script>

</body>

</html>
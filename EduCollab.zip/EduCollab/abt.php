<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "educollab";
$conn = mysql_connect($server,$username,$password);
$db = mysql_select_db($dbname);

$a = $_POST["about"];
$b = $_POST["link"];
    
    $qry="insert into clg values('$a','$b')";    
    $res=mysql_query($qry);
    echo $res;
     if($res==1)
     {
         echo "<script> alert('Data added successfully')</script>";
         echo "<script> window.location.href='college.php' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
            echo "<script> window.location.href='clg.php' </script>";
        }
?>
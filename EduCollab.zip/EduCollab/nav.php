<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

  <link
    href="https://fonts.googleapis.com/css2?family=Display+Playfair:wght@400;700&family=Inter:wght@400;700&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  <link rel="stylesheet" href="css/ashish.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
  <title>EduCollab</title>
</head>

<body>

  <div class="site-mobile-menu">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

  <!-- Include Bootstrap CSS (you may need to adjust the path to your CSS file) -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.5.0/dist/css/bootstrap.min.css">
  </head>

  <body>

    <nav class="site-nav mb-5">
      <div class="pb-2 top-bar mb-3">
        <div class="container">
          <div class="row align-items-center">

            <div class="col-6 col-lg-9">
              <a href="#" class="small mr-3"><span class="icon-question-circle-o mr-2"></span> <span
                  class="d-none d-lg-inline-block">Have a question?</span></a>
              <a href="#" class="small mr-3"><span class="icon-phone mr-2"></span> <span
                  class="d-none d-lg-inline-block">+918780564301</span></a>
              <a href="#" class="small mr-3"><span class="icon-envelope mr-2"></span> <span
                  class="d-none d-lg-inline-block">vajaashish200@.com</span></a>

            </div>

            <div class="col-6 col-lg-3 text-right">
              <a href="login.html" class="small mr-3">
                <span class="icon-lock"></span>
                Log In
              </a>
              <a href="select.html" class="small">
                <span class="icon-person"></span>
                Register
              </a>
            </div>

          </div>
        </div>
      </div>
      <div class="sticky-nav js-sticky-header">
        <div class="container position-relative">
          <div class="site-navigation text-center">
            <a href="index.html" class="logo menu-absolute"><span class="log">Edu<span
                  class="c">C</span>ollab</span></a>

            <!-- Add the search bar here -->
            <form class="d-inline-block d-lg-none">
              <input class="form-control form-control-sm" type="search" placeholder="Search" aria-label="Search">
            </form>

            <ul class="js-clone-nav d-none d-lg-inline-block site-menu">
              <li class="has-children">
                <a href="#">MBA</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="https://www.iima.ac.in/">IIM Ahmedabad</a></li>
                      <li><a href="https://www.upgrad.com/digital-marketing-and-communication-pgc-mica/?utm_source=GOOGLE&utm_medium=NBSEARCH&utm_campaign=IND_ACQ_WEB_GOOGLE_NBSEARCH_PD_MICA_DM_KEYWORDS_UNIVERSITY_T1&utm_content=Mica_Exact&utm_term=mica%20ahmedabad&gad_source=1&gclid=CjwKCAiAqNSsBhAvEiwAn_tmxQ0MXILrYNbo9YZDPktkZz2Wkk3imDzUGNJP07Df7eNmTxp5pB16RxoChUwQAvD_BwE">MICA</a></li>
                      <li><a href="https://msub.digitaluniversity.ac/">MSU Baroda</a></li>
                      <li><a href="https://nirmauni.ac.in/">Nirma University </a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Popular courses</a>
                    <ul class="dropdown">
                      <li><a href="https://www.greatlakes.edu.in/chennai/pgdm/blog/mba-vs-pgdm">MBA/PGDM</a></li>
                      <li><a href="https://admissions.mitsde.com/?utm_source=Google-ads&utm_medium=ExecutiveMBA&utm_campaign=EMBA&gad_source=1&gclid=CjwKCAiAqNSsBhAvEiwAn_tmxW3uWYzwptnBeXMnnO9YoUEfFX8-3gpUe96xLxRMMG86DPEyCIHLNhoCV6QQAvD_BwE">Executive MBA</a></li>
                      <li><a href="https://onlinemba.paruluniversity.online/?utm_source=google_search_srv_online&utm_medium=distance_generic_keywords_top_states&utm_campaign=Distance_MBA_Course&gad_source=1&gclid=CjwKCAiAqNSsBhAvEiwAn_tmxRRqgEhzfvTGErBDOG_UOiB-ipwINuybyl-Lyl0pp2QpciY9RueP6hoCbpkQAvD_BwE">Distance MBA</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="https://www.shiksha.com/studyabroad/usa/universities/american-university/courses/teaching-and-education-s?t_source=paid&utm_source=google&utm_medium=cpc&utm_campaign=Studyabroad_usa_SN_India-ds-study&gclid=CjwKCAiAqNSsBhAvEiwAn_tmxbDm9Zz_UaWyVCeHaYW2iJU2qbDiZGo8jOOUM0qhRZSuebmpqp_ohxoCrRAQAvD_BwE">Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">CAT</a></li>
                      <li><a href="https://www.shiksha.com/studyabroad/usa/universities/american-university/courses/teaching-and-education-s?t_source=paid&utm_source=google&utm_medium=cpc&utm_campaign=Studyabroad_usa_SN_India-ds-study&gclid=CjwKCAiAqNSsBhAvEiwAn_tmxbDm9Zz_UaWyVCeHaYW2iJU2qbDiZGo8jOOUM0qhRZSuebmpqp_ohxoCrRAQAvD_BwE">XAT</a></li>
                      <li><a href="#">SNAP</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Compare college</a>
                    <ul class="dropdown">
                      <li><a href="#">IIM Ahmedabad vs. Shailesh J Maheta school of management </a></li>
                      <li><a href="#">IIM Ahmedabad vs. IIM Banglore</a></li>
                      <li><a href="#">IIM Ahmedabad vs. IIM Lucknow</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li class="has-children">
                <a href="#">ENGINEERING</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="#">IIT Gandhinagar</a></li>
                      <li><a href="#">MSU Baroda</a></li>
                      <li><a href="#">Nirma University</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Popular courses</a>
                    <ul class="dropdown">
                      <li><a href="#">BE/B.TECH</a></li>
                      <li><a href="#">ME/M.TECH</a></li>
                      <li><a href="#">PHD</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">JEE </a></li>
                      <li><a href="#">GATE</a></li>
                      <li><a href="#">JET</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Compare college</a>
                    <ul class="dropdown">
                      <li><a href="#">Nirma University vs. Parul University </a></li>
                      <li><a href="#">IIT Gandhinagar vs. L.D Ahmedabad</a></li>
                      <li><a href="#">GEC Modasa vs. GEC Patan</a></li>
                    </ul>
                  </li>
                </ul>
              <li class="has-children">
                <a href="#">MEDICAL</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="#">B.J. MEDICAL COLLEGE</a></li>
                      <li><a href="#">Shree M.P Shaah</a></li>
                      <li><a href="#">AIIMS Rajkot</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Popular courses</a>
                    <ul class="dropdown">
                      <li><a href="#">MBBS</a></li>
                      <li><a href="#">MD</a></li>
                      <li><a href="#">MPH</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">NEET UG </a></li>
                      <li><a href="#">NEET PG</a></li>
                      <li><a href="#">NEET SS</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Compare college</a>
                    <ul class="dropdown">
                      <li><a href="#">B.J Medical vs. CU Shaah Medical </a></li>
                      <li><a href="#">GCS Medical vs. GMERS Medical </a></li>
                      <li><a href="#">GMERS Medical vs. Government Medical College </a></li>
                    </ul>
                  </li>
                </ul>
              <li class="has-children">
                <a href="#">DESIGN</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="#">AURO University</a></li>
                      <li><a href="#">Karnavati University</a></li>
                      <li><a href="#">P.P Savani University</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Popular courses</a>
                    <ul class="dropdown">
                      <li><a href="#">B.DES</a></li>
                      <li><a href="#">M.DES</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">CEED </a></li>
                      <li><a href="#">UCEED</a></li>
                    </ul>
                  </li>
                </ul>
              <li class="has-children">
                <a href="#">MORE</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Banking</a>
                    <ul class="dropdown">
                      <li><a href="#">IBPS Cleark</a></li>
                      <li><a href="#">SBI Cleark</a></li>
                      <li><a href="#">SBI PO</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">All Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">UPSC</a></li>
                      <li><a href="#">All Sarkari Exams</a></li>
                      <li><a href="#">Scholarship Exams</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Career after 12th</a>
                    <ul class="dropdown">
                      <li><a href="#">Arts </a></li>
                      <li><a href="#">Commerce</a></li>
                      <li><a href="#">Science</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Career tests</a>
                  </li>
                </ul>
              <li><a href="news.html">LATEST NEWS</a></li>
            </ul>
            <a href="test.html" class="btn-book btn btn-warning btn-sm menu-absolute">Chat with counsellor</a>
            <a href="#"
              class="burger ml-auto float-right site-menu-toggle js-menu-toggle d-inline-block d-lg-none light"
              data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>

          </div>
        </div>
      </div>
    </nav>

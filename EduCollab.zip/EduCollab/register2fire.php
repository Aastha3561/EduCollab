<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "educollab";
$conn = mysql_connect($server,$username,$password);
$db = mysql_select_db($dbname);
$x = $_POST["code"];   
$a = $_POST["name"];
	$b = $_POST["email"];
    $c = $_POST["phone"];
    $y = $_POST["year"];
    $h = $_POST["city"];
    $d = $_POST["uni"];
    $e = $_POST["no"];
    $f = $_POST["pass"];
    $g = $_POST["rpass"];
    echo "'$a','$b','$c','$y','$h','$d','$e','$f','$h','$g'";
    $qry="insert into register2 values('$x','$a','$b','$c','$y','$h','$d','$e','$f','$g')";    
    $res=mysql_query($qry);
    echo $res;
     if($res==1)
     {
         echo "<script> alert('Register successfully')</script>";
         echo "<script> window.location.href='index.html' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>
<?php

	session_start();
	$user=$_SESSION['user'];
  if($user=="")
	{
		$user="Guest";
        
    }
	else
	{
		$qry="SELECT * from register2 where email='$user'";
		$rr=mysql_query($qry);
  
	}
	
?>


<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

  <link href="https://fonts.googleapis.com/css2?family=Display+Playfair:wght@400;700&family=Inter:wght@400;700&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/ashish.css">
  <title>College page</title>
</head>

<body>

  <div class="site-mobile-menu">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>


  
  <nav class="site-nav mb-5">
    <div class="pb-2 top-bar mb-3">
      <div class="container">
        <div class="row align-items-center">

          <div class="col-6 col-lg-9">
            <a href="#" class="small mr-3"><span class="icon-envelope mr-2"></span><span class="man">Welcome  <span class="d-none d-lg-inline-block"><?php echo $user ?></span></span></a> 
          </div>

          <div class="col-6 col-lg-3 text-right">
          
          </div>

        </div>
      </div>
    </div>
    <div class="sticky-nav js-sticky-header">
        <div class="container position-relative">
          <div class="site-navigation text-center">
            <a href="index.html" class="logo menu-absolute"><span class="log">Edu<span
                  class="c">C</span>ollab</span></a>


          <ul class="js-clone-nav d-none d-lg-inline-block site-menu">
            <li><a href="college.php">Home</a></li>
            
            <li><a href="clgabout.php">About</a></li>
            <li><a href="course.php">Courses</a></li>
            <li><a href="gallery.html">Departments</a></li>
             <li><a href="contact.html">Contact</a></li>
          </ul>

          <a href="signout.php" class="btn-book btn btn-warning btn-sm menu-absolute">  
              <span class="icon-lock"></span>
              Log out
            </a>
       </a>

          <a href="#" class="burger ml-auto float-right site-menu-toggle js-menu-toggle d-inline-block d-lg-none light" data-toggle="collapse" data-target="#main-navbar">
            <span></span>
          </a>

        </div>
      </div>
    </div>
  </nav>
  

  <div class="untree_co-hero inner-page overlay" style="background-image: url('images/img-school-5-min.jpg');">
    <div class="container">
      <div class="row align-items-center justify-content-center">
        <div class="col-12">
          <div class="row justify-content-center ">
            <div class="col-lg-6 text-center ">
              <h1 class="mb-4 heading text-white" data-aos="fade-up" data-aos-delay="100">Add course description</h1>

            </div>
          </div>
        </div>
      </div> <!-- /.row -->
    </div> <!-- /.container -->

  </div> <!-- /.untree_co-hero -->

<br>
<br><br>
<br>


  <div class="untree_co-section">
    <div class="container">

      <div class="row mb-5 justify-content-center">
        <div class="col-lg-12 mx-auto order-1" data-aos="fade-up" data-aos-delay="200">
          <form action="coursefire.php" class="form-box" method="post" >
            <div class="row">
            <div class="col-12 mb-3">
                <label>Enter Course code*</label>
                <input type="text" class="form-control"  name="code">
              </div>
              
            <div class="col-12 mb-3">
                <label>Enter Course name*</label>
                <input type="text" class="form-control"   name="name">
              </div>
              <div class="form-control col-lg-7">
                                <label>certify..? </label>
                                &nbsp;
                                <input type="radio" value="c" name="c">Yes
                                <input type="radio" value="b" name="c"> No
                             </div>
            <div class="col-12 mb-3">
                <label>Enter total no. lessons*</label>
                <input type="text" class="form-control"  name="lesson">
              </div>
              <div class="col-12 mb-3">
                <label>Enter Course details*</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="8" name="dis"> </textarea>    </div>
                <div class="col-12 mb-3">
                <label>Enter price*</label>
                <input type="text" class="form-control" name="price" >
              </div>
              <div class="col-12 mb-3">
              <label for = "inputfile">Upload Image:-</label>
  <input class="form-control" type="file"  id = "inputfile" name="userfile"  width="200" height="200" >
  <p class = "help-block">Upload clean vision .jpg image size of image must be 400*200</p>
  <p class = "help-block">Must upload the name of file with same name of course code</p>
</div>
                <div class="col-12 mb-3">
           
              <div class="col-12">
                <input type="submit" value="submit" class="btn col-md-12 btn-primary">
         
            </div>
          </form>
        </div>
      </div>

      
    </div>
  </div> <!-- /.untree_co-section -->


    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/custom.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.5.0/dist/js/bootstrap.min.js"></script>

</body>

</html>
<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "educollab";
$conn = mysql_connect($server,$username,$password);
$db = mysql_select_db($dbname);


		$a = $_POST["email"];
		$b = $_POST["pass"];

	
  	$sel = "select * from register where email='$a' and pass='$b' ";
	$res = mysql_query($sel);
	$count = mysql_num_rows($res);
	
	if($count==1)
	{
		session_start();
		$_SESSION['user']=$a;	
		echo "<script> alert('Login Successfully');</script>";
		echo "<script> window.location = 'index.html' </script>";
	}
	else
	{
		echo "<script> alert('Login credential are incorrect'); </script>";
		echo "<script> window.location = 'login.html' </script>";
	}
	
	
	
?>
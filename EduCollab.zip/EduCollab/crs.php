<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

  <link href="https://fonts.googleapis.com/css2?family=Display+Playfair:wght@400;700&family=Inter:wght@400;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  <link rel="stylesheet" href="css/ashish.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
  <title>EduCollab</title>


  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .custom-media img {
            width: 100%;
            height: 200px; /* Set a fixed height */
            object-fit: cover; /* Ensure the image covers the area without distortion */
        }
        .car__item__text {
            text-align: center;
            padding: 10px;
        }
        .mycl {
            font-size: 1.2em;
            font-weight: bold;
        }
        .mm {
            color: #007bff;
        }
    </style>

 

      <!-- Include Bootstrap CSS (you may need to adjust the path to your CSS file) -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.5.0/dist/css/bootstrap.min.css">
  </head>
  <body>
  
    <nav class="site-nav mb-5">
      <div class="pb-2 top-bar mb-3">
        <div class="container">
          <div class="row align-items-center">
    
            <div class="col-6 col-lg-9">
              <a href="#" class="small mr-3"><span class="icon-question-circle-o mr-2"></span> <span class="d-none d-lg-inline-block">Have a question?</span></a>
              <a href="#" class="small mr-3"><span class="icon-phone mr-2"></span> <span class="d-none d-lg-inline-block">+918780564301</span></a>
              <a href="#" class="small mr-3"><span class="icon-envelope mr-2"></span> <span class="d-none d-lg-inline-block">vajaashish200@.com</span></a>
           
            </div>
    
            <div class="col-6 col-lg-3 text-right">
              <a href="login.html" class="small mr-3">
                <span class="icon-lock"></span>
                Log In
              </a>
              <a href="register.html" class="small">
                <span class="icon-person"></span>
                Register
              </a>
            </div>
    
          </div>
        </div>
      </div>
      <div class="sticky-nav js-sticky-header">
        <div class="container position-relative">
          <div class="site-navigation text-center">
            <a href="index.html" class="logo menu-absolute"><span class="log">Edu<span class="c">C</span>ollab</span></a>
    
            <!-- Add the search bar here -->
            <form class="d-inline-block d-lg-none">
              <input class="form-control form-control-sm" type="search" placeholder="Search" aria-label="Search">
            </form>
    
            <ul class="js-clone-nav d-none d-lg-inline-block site-menu">
              <li class="has-children">
                <a href="#">MBA</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="#">IIM Ahmedabad</a></li>
                      <li><a href="#">MICA</a></li>
                      <li><a href="#">MSU Baroda</a></li>
                      <li><a href="#">Nirma University </a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                  <a href="#">Popular courses</a>
                  <ul class="dropdown">
                    <li><a href="#">MBA/PGDM</a></li>
                    <li><a href="#">Executive MBA</a></li>
                    <li><a href="#">Distance MBA</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#">Exams</a>
                  <ul class="dropdown">
                    <li><a href="#">CAT</a></li>
                    <li><a href="#">XAT</a></li>
                    <li><a href="#">SNAP</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#">Compare college</a>
                  <ul class="dropdown">
                    <li><a href="#">IIM Ahmedabad vs. Shailesh J Maheta school of management </a></li>
                    <li><a href="#">IIM Ahmedabad vs. IIM Banglore</a></li>
                    <li><a href="#">IIM Ahmedabad vs. IIM Lucknow</a></li>
                  </ul>
                </li>
                </ul>
              </li>
              <li class="has-children">
                <a href="#">ENGINEERING</a>
                <ul class="dropdown">
                  <li class="has-children">
                    <a href="#"> Ranked colleges</a>
                    <ul class="dropdown">
                      <li><a href="#">IIT Gandhinagar</a></li>
                      <li><a href="#">MSU Baroda</a></li>
                      <li><a href="#">Nirma University</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                  <a href="#">Popular courses</a>
                  <ul class="dropdown">
                    <li><a href="#">BE/B.TECH</a></li>
                    <li><a href="#">ME/M.TECH</a></li>
                    <li><a href="#">PHD</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#">Exams</a>
                  <ul class="dropdown">
                    <li><a href="#">JEE </a></li>
                    <li><a href="#">GATE</a></li>
                    <li><a href="#">JET</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#">Compare college</a>
                  <ul class="dropdown">
                    <li><a href="#">Nirma University vs. Parul University </a></li>
                    <li><a href="#">IIT Gandhinagar vs. L.D Ahmedabad</a></li>
                    <li><a href="#">GEC Modasa vs. GEC Patan</a></li>
                  </ul>
                </li>
                </ul>
                <li class="has-children">
                  <a href="#">MEDICAL</a>
                  <ul class="dropdown">
                    <li class="has-children">
                      <a href="#"> Ranked colleges</a>
                      <ul class="dropdown">
                        <li><a href="#">B.J. MEDICAL COLLEGE</a></li>
                        <li><a href="#">Shree M.P Shaah</a></li>
                        <li><a href="#">AIIMS Rajkot</a></li>
                      </ul>
                    </li>
                    <li class="has-children">
                    <a href="#">Popular courses</a>
                    <ul class="dropdown">
                      <li><a href="#">MBBS</a></li>
                      <li><a href="#">MD</a></li>
                      <li><a href="#">MPH</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Exams</a>
                    <ul class="dropdown">
                      <li><a href="#">NEET UG </a></li>
                      <li><a href="#">NEET PG</a></li>
                      <li><a href="#">NEET SS</a></li>
                    </ul>
                  </li>
                  <li class="has-children">
                    <a href="#">Compare college</a>
                    <ul class="dropdown">
                      <li><a href="#">B.J Medical vs. CU Shaah Medical  </a></li>
                      <li><a href="#">GCS Medical vs. GMERS Medical </a></li>
                      <li><a href="#">GMERS Medical vs. Government Medical College </a></li>
                    </ul>
                  </li>
                  </ul>
                  <li class="has-children">
                    <a href="#">DESIGN</a>
                    <ul class="dropdown">
                      <li class="has-children">
                        <a href="#"> Ranked colleges</a>
                        <ul class="dropdown">
                          <li><a href="#">AURO University</a></li>
                          <li><a href="#">Karnavati University</a></li>
                          <li><a href="#">P.P Savani University</a></li>
                        </ul>
                      </li>
                      <li class="has-children">
                      <a href="#">Popular courses</a>
                      <ul class="dropdown">
                        <li><a href="#">B.DES</a></li>
                        <li><a href="#">M.DES</a></li>
                      </ul>
                    </li>
                    <li class="has-children">
                      <a href="#">Exams</a>
                      <ul class="dropdown">
                        <li><a href="#">CEED </a></li>
                        <li><a href="#">UCEED</a></li>
                      </ul>
                    </li>
                    </ul>
                    <li class="has-children">
                      <a href="#">MORE</a>
                      <ul class="dropdown">
                        <li class="has-children">
                          <a href="#"> Banking</a>
                          <ul class="dropdown">
                            <li><a href="#">IBPS Cleark</a></li>
                            <li><a href="#">SBI Cleark</a></li>
                            <li><a href="#">SBI PO</a></li>
                          </ul>
                        </li>
                        <li class="has-children">
                        <a href="#">All Exams</a>
                        <ul class="dropdown">
                          <li><a href="#">UPSC</a></li>
                          <li><a href="#">All Sarkari Exams</a></li>
                          <li><a href="#">Scholarship Exams</a></li>
                        </ul>
                      </li>
                      <li class="has-children">
                        <a href="#">Career after 12th</a>
                        <ul class="dropdown">
                          <li><a href="#">Arts </a></li>
                          <li><a href="#">Commerce</a></li>
                          <li><a href="#">Science</a></li>
                        </ul>
                      </li>
                      <li class="has-children">
                        <a href="#">Career tests</a>
                      </li>
                      </ul>
              <li><a href="news.html">LATEST NEWS</a></li>
              </ul>
          <a href="#" class="btn-book btn btn-warning btn-sm menu-absolute">Chat with counsellor</a> 
            <a href="#" class="burger ml-auto float-right site-menu-toggle js-menu-toggle d-inline-block d-lg-none light" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
    
          </div>
        </div>
      </div>
    </nav>
  <div class="untree_co-hero inner-page overlay" style="background-image: url('images/img-school-5-min.jpg');">
    <div class="container">
      <div class="row align-items-center justify-content-center">
        <div class="col-12">
          <div class="row justify-content-center ">
            <div class="col-lg-6 text-center ">
              <h1 class="mb-4 heading text-white" data-aos="fade-up" data-aos-delay="100">Login</h1>

            </div>
          </div>
        </div>
      </div> <!-- /.row -->
    </div> <!-- /.container -->

  </div> <!-- /.untree_co-hero -->



<body>
    <div class="untree_co-section bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-lg-7 text-center">
                    <h2 class="line-bottom text-center mb-4">Get Certified With Us</h2>
                    <p>We have a wide variety of courses to select from, choose any of the courses and get Certified.</p>
                </div>
            </div>
            <div class="row">
                <?php
                // Database connection details
                $server = "localhost";
                $username = "root";
                $password = "";
                $dbname = "educollab";

                // Create connection
                $conn = new mysqli($server, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Define the query
                $qry = "SELECT * FROM course ORDER BY flag DESC";

                // Execute the query
                $rc = $conn->query($qry);

                // Check if the query was successful
                if ($rc === false) {
                    die("Error: " . $conn->error);
                }

                $i = 0; // counter
                while ($row = $rc->fetch_assoc()) {
                    if ($i % 3 == 0) { // if counter is multiple of 3
                        if ($i != 0) { // close previous row if not the first row
                            echo '</div>';
                        }
                        echo '<div class="row">';
                    }
                ?>
              
                <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
                    <div class="custom-media">
                        <?php echo "<a href='crsd.php?code={$row['code']}'>  <img class='img-responsive img-hover' src='thumb/{$row['image']}'>  </a>"; ?>
                        <div class="car__item__text">
                            <h4 class="mycl"><?php echo $row['name']; ?></h4>
                            <p>Price: Rs <?php echo $row['price']; ?></p>
                            <p>Total Lessons: <?php echo $row['total_lessons']; ?></p>
                            <h6>
                                <?php echo "<a href='crsd.php?code={$row['code']}' class='mm'> <i class='fa fa-external-link' aria-hidden='true'></i> View Course Details</a>"; ?>
                            </h6>
                        </div>
                    </div>
                </div>
              
                <?php 
                    $i++; 
                } 
                if ($i % 3 != 0) { // close the last row if it's not already closed
                    echo '</div>';
                }

                // Close the connection
                $conn->close();
                ?>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

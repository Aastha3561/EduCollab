<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "educollab";
    $conn = mysql_connect($server,$username,$password);
    $db = mysql_select_db($dbname);
?>
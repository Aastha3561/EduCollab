<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "educollab";
$conn = mysql_connect($server,$username,$password);
$db = mysql_select_db($dbname);
    $a = $_POST["name"];
	$b = $_POST["email"];
    $c = $_POST["phone"];
    $d = $_POST["pass"];
    $e = $_POST["rpass"];
    $f = $_POST["date"];
    $g = $_POST["type"];
    //echo "'$a','$b','$c','$d','$e','$f','$h','$g'";
    $qry="insert into register values('$a','$b','$c','$d','$e','$f','$g')";    
    $res=mysql_query($qry);
    echo $res;
     if($res==1)
     {
         echo "<script> alert('Register successfully')</script>";
         echo "<script> window.location.href='index.html' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>